import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:todoproject/database.dart';
import 'package:todoproject/todo_tile.dart';

import 'dialog.dart';
import 'home.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  // reference to hive box
  final _mybox = Hive.box('mybox');

  final _controller = TextEditingController();
  TodoDatabase db = TodoDatabase();
  @override
  void initState() {
    // if this is the 1st time opening the app
    if (_mybox.get("TODOLIST") == null) {
      // db.createInitialData();
    } else {
      db.loadData();
    }
    super.initState();
  }

  // List toDoList = [
  //   // ["Make Tutorial", false],
  //   // ["Do Exercise", false],
  //   // ["Do job", true],
  //   // ["Do Fucking shit", false],
  //   // ["Play Efootball 2023", true],
  //   // ["Do Exercise", false],
  // ];
  bool get hasTasks => db.toDoList.isNotEmpty;

  @override
  void dispose() {
    _controller.dispose(); // Dispose the TextEditingController
    super.dispose();
  }

  ///check box haddii click lasiiyo caksi hanoqdo, if true: false, if false: true.
  void checkBoxChanged(bool? value, int index) {
    setState(() {
      db.toDoList[index][1] = !db.toDoList[index][1];
    });
    db.updataeDatabase();
  }

  ////////////////////////////////////////////////////
///////////////////////////////
  void createNewTask() {
    showDialog(
      context: context,
      builder: (context) {
        //// DialongBoxWidget: waxa uu kasameesan yahay dialon.dart: waa widget guud oo wato 3 required ah: controller, Onsave iyo OnCancel.
        return DialongBoxWidget(
          storeNewTask: _controller,
          // waxaan isku daye inaa function gooni ah usameeyo, lknse error aya igu qabsade, balse sidaan ayaa ii shaqeese alx....
          OnSave: () {
            final enteredText = _controller.text.trim();
            if (enteredText.isNotEmpty) {
              setState(() {
                db.toDoList.add([enteredText, false]);
              });
            }
            db.updataeDatabase();
            Navigator.of(context).pop();
            _controller.clear();
          },

          OnCancel: () => Navigator.of(context).pop(),
        ); // waxaa meshan ku xeran widgetkii aan ku sameeye dialong oo aan halkaan uga wacay oona watay 3xdii requiredka eheed..
      },
    );
  }

  void delFun(int index) {
    setState(() {
      db.toDoList.removeAt(index);
    });
    db.updataeDatabase();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orange[200],
      appBar: AppBar(
        toolbarHeight: 100, // Set the desired height for the AppBar

        centerTitle: true,
        title: Text(
          "TODO PROJECT BY FAITH JIMALE",
          style: TextStyle(color: Colors.black),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: createNewTask,
        child: Icon(Icons.add),
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(top: 20),
          child: Column(
            children: [
              Text(
                "------------------------ PROJECT 2--------------------",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                "------------- DATE DEVELOPED 8 AUG 2023---------",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              Center(
                child: Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (!hasTasks)
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Text(
                              "Please click the add button to add a task.",
                              style: TextStyle(fontSize: 18),
                            ),
                          ),
                        ),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: db.toDoList.length,
                        itemBuilder: (context, index) {
                          return TodoTile(
                            taskName: db.toDoList[index][0],
                            tasksCompleted: db.toDoList[index][1],
                            onChanged: (value) => checkBoxChanged(value, index),
                            deleteFunction: (context) => delFun(index),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


// import 'package:flutter/material.dart';
// import 'package:todoproject/todo_tile.dart';

// import 'dialog.dart';

// class Home extends StatefulWidget {
//   const Home({Key? key}) : super(key: key);

//   @override
//   State<Home> createState() => _HomeState();
// }

// class _HomeState extends State<Home> {
//   final _controller = TextEditingController();
//   List toDoList = [];

//   bool get hasTasks => toDoList.isNotEmpty;

//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }

//   void checkBoxChanged(bool? value, int index) {
//     setState(() {
//       toDoList[index][1] = !toDoList[index][1];
//     });
//   }

//   void createNewTask() {
//     showDialog(
//       context: context,
//       builder: (context) {
//         return DialongBoxWidget(
//           controller: _controller,
//           OnSave: () {
//             final enteredText = _controller.text.trim();
//             if (enteredText.isNotEmpty) {
//               setState(() {
//                 toDoList.add([enteredText, false]);
//               });
//             }
//             Navigator.of(context).pop();
//             _controller.clear();
//           },
//           OnCancel: () => Navigator.of(context).pop(),
//         );
//       },
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.orange[200],
//       appBar: AppBar(
//         centerTitle: true,
//         title: Text(
//           "TODO PROJECT...",
//           style: TextStyle(color: Colors.black),
//         ),
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: createNewTask,
//         child: Icon(Icons.add),
//       ),
//       body: SingleChildScrollView(
//         child: Column(
//           children: [
//             if (!hasTasks)
//               Padding(
//                 padding: const EdgeInsets.all(20.0),
//                 child: Text(
//                   "Please click the add button to add a task.",
//                   style: TextStyle(fontSize: 18),
//                 ),
//               ),
//             ListView.builder(
//               shrinkWrap: true,
//               physics: NeverScrollableScrollPhysics(),
//               itemCount: toDoList.length,
//               itemBuilder: (context, index) {
//                 return TodoTile(
//                   taskName: toDoList[index][0],
//                   tasksCompleted: toDoList[index][1],
//                   onChanged: (value) => checkBoxChanged(value, index),
//                 );
//               },
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// void main() {
//   runApp(
//     MaterialApp(
//       home: Home(),
//     ),
//   );
// }