import 'package:flutter/material.dart';
import 'package:todoproject/myButton.dart';

class DialongBoxWidget extends StatelessWidget {
  final storeNewTask;
  VoidCallback OnSave;
  VoidCallback OnCancel;
  DialongBoxWidget(
      {super.key,
      required this.storeNewTask,
      required this.OnSave,
      required this.OnCancel});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.yellow[300],
      content: Container(
        height: 150,
        width: 350,
        child:
            Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          /////////// xogta cusub meshan aya akasoo galinee: Taskga cusub gali.
          TextField(
            controller: storeNewTask,   /// storeNewTask: waxaa ku keedsami doono xogta cusub oo taskga aa soo galino.
            /// waxaana rabaa in variablekaan lagu isticmaali karo home.dart: cause meshas ayaa larabaa in algu soo bandhigo. sidaa awgeed waxaan kadhigay required.
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              hintText: "Add a new task",
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              /// myButtons: waa widget iigu diyaarsan myButton.dart: wuxuu iifududeenaa in aan si fudud kusameesto button, wuxuuna wataa 2 parameter: text(kasoo muuqanaayo buttonka) iyo OnPressed: oo ah buttonka markii click lasiiyo wixii so bixi lahaa.
              myButtons(text: "Save", onPressed: OnSave),
              SizedBox(
                width: 8,
              ),
              myButtons(text: "Cancel", onPressed: OnCancel),
            ],
          )
        ]),
        // width: 100,
      ),
    );
  }
}
