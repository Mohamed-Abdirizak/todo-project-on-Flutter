import 'package:hive_flutter/hive_flutter.dart';

class TodoDatabase {
  List toDoList = [];

  /// reference our box
  final _myBox = Hive.box('mybox');
/////if this is the first time ever the app...
  void createInitialData() {
    toDoList = [
      ["Make Tutorial", false],
      ["Do Exercise", false],
    ];
  }

// load the data from the dtabase.
  void loadData() {
    toDoList = _myBox.get("TODOLIST");
  }

// update the database
  void updataeDatabase() {
    _myBox.put("TODOLIST", toDoList);
  }
}
